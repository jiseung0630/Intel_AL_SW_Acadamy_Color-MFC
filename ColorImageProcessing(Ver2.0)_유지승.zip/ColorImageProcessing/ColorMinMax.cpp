﻿// ColorMinMax.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageProcessing.h"
#include "afxdialogex.h"
#include "ColorMinMax.h"


// CColorMinMax 대화 상자

IMPLEMENT_DYNAMIC(CColorMinMax, CDialog)

CColorMinMax::CColorMinMax(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_COLOR_MINMAX, pParent)
	, m_MinColor(0)
	, m_MaxColor(0)
{

}

CColorMinMax::~CColorMinMax()
{
}

void CColorMinMax::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_COLORMIN, m_MinColor);
	DDV_MinMaxInt(pDX, m_MinColor, 0, 360);
	DDX_Text(pDX, IDC_EDIT_COLORMAX, m_MaxColor);
	DDV_MinMaxInt(pDX, m_MaxColor, 0, 360);
}


BEGIN_MESSAGE_MAP(CColorMinMax, CDialog)
END_MESSAGE_MAP()


// CColorMinMax 메시지 처리기
