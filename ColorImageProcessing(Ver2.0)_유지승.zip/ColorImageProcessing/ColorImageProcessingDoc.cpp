﻿
// ColorImageProcessingDoc.cpp: CColorImageProcessingDoc 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "ColorImageProcessing.h"
#endif

#include "ColorImageProcessingDoc.h"

#include <propkey.h>
#include "ConstantDlg.h"
#include "XYConstantDlg.h"
#include "BlurConstant.h"
#include "ColorMinMax.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CColorImageProcessingDoc

IMPLEMENT_DYNCREATE(CColorImageProcessingDoc, CDocument)

BEGIN_MESSAGE_MAP(CColorImageProcessingDoc, CDocument)
END_MESSAGE_MAP()


// CColorImageProcessingDoc 생성/소멸

CColorImageProcessingDoc::CColorImageProcessingDoc() noexcept
{
	// TODO: 여기에 일회성 생성 코드를 추가합니다.

}

CColorImageProcessingDoc::~CColorImageProcessingDoc()
{
}

BOOL CColorImageProcessingDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: 여기에 재초기화 코드를 추가합니다.
	// SDI 문서는 이 문서를 다시 사용합니다.

	return TRUE;
}




// CColorImageProcessingDoc serialization

void CColorImageProcessingDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: 여기에 저장 코드를 추가합니다.
	}
	else
	{
		// TODO: 여기에 로딩 코드를 추가합니다.
	}
}

#ifdef SHARED_HANDLERS

// 축소판 그림을 지원합니다.
void CColorImageProcessingDoc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// 문서의 데이터를 그리려면 이 코드를 수정하십시오.
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// 검색 처리기를 지원합니다.
void CColorImageProcessingDoc::InitializeSearchContent()
{
	CString strSearchContent;
	// 문서의 데이터에서 검색 콘텐츠를 설정합니다.
	// 콘텐츠 부분은 ";"로 구분되어야 합니다.

	// 예: strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CColorImageProcessingDoc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = nullptr;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != nullptr)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CColorImageProcessingDoc 진단

#ifdef _DEBUG
void CColorImageProcessingDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CColorImageProcessingDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CColorImageProcessingDoc 명령


BOOL CColorImageProcessingDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	// TODO:  여기에 특수화된 작성 코드를 추가합니다.
	//기존 메모리 해제
	if (m_inImageR != NULL) {
		OnFree2D(m_inImageR, m_inH);
		OnFree2D(m_inImageG, m_inH);
		OnFree2D(m_inImageB, m_inH);
		m_inImageR = m_inImageG = m_inImageB = NULL;
		m_inH = m_inW = 0;

		OnFree2D(m_outImageR, m_outH);
		OnFree2D(m_outImageG, m_outH);
		OnFree2D(m_outImageB, m_outH);
		m_outImageR = m_outImageG = m_outImageB = NULL;
		m_outH = m_outW = 0;
	}
	// TODO:  여기에 특수화된 작성 코드를 추가합니다.
	CImage image;
	image.Load(lpszPathName);
	//(중요!) 입력 영상 크기 알아내기~
	m_inH = image.GetHeight();
	m_inW = image.GetWidth();
	//메모리 할당
	m_inImageR = OnMalloc2D(m_inH, m_inW,0);
	m_inImageG = OnMalloc2D(m_inH, m_inW,0);
	m_inImageB = OnMalloc2D(m_inH, m_inW,0);
	//CImage의 객체값 --> 메모리
	COLORREF px;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			px = image.GetPixel(k, i);
			m_inImageR[i][k] = GetRValue(px);
			m_inImageG[i][k] = GetGValue(px);
			m_inImageB[i][k] = GetBValue(px);
		}
	}
	return TRUE;
}


void CColorImageProcessingDoc::OnFree2D(unsigned char** memory, int h)
{
	// TODO: 여기에 구현 코드 추가.
	if (memory == NULL) {
		return;
	}
	for (int i = 0; i < h; i++) {
		delete memory[i];
	}
	delete[] memory;
}

void CColorImageProcessingDoc::OnFree2DDouble(double** memory, int h)
{
	// TODO: 여기에 구현 코드 추가.
	if (memory == NULL) {
		return;
	}
	for (int i = 0; i < h; i++) {
		delete memory[i];
	}
	delete[] memory;
}

unsigned char** CColorImageProcessingDoc::OnMalloc2D(int h, int w, int initValue)
{
	// TODO: 여기에 구현 코드 추가.
	unsigned char** memory;
	memory = new unsigned char* [h];
	for (int i = 0; i < h; i++) {
		memory[i] = new unsigned char[w];
	}
	for (int i = 0; i < h; i++) {
		for (int k = 0; k < w; k++) {
			memory[i][k] = initValue;
		}
	}
	return memory;

}


void CColorImageProcessingDoc::OnCloseDocument()
{
	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
	OnFree2D(m_inImageR, m_inH);
	OnFree2D(m_inImageG, m_inH);
	OnFree2D(m_inImageB, m_inH);

	OnFree2D(m_outImageR, m_outH);
	OnFree2D(m_outImageG, m_outH);
	OnFree2D(m_outImageB, m_outH);

	CDocument::OnCloseDocument();
}


void CColorImageProcessingDoc::OnFreeOutImage()
{
	// TODO: 여기에 구현 코드 추가.
	if (m_outImageR != NULL) {
		OnFree2D(m_outImageR, m_outH);
		OnFree2D(m_outImageG, m_outH);
		OnFree2D(m_outImageB, m_outH);
		m_outImageR = m_outImageG = m_outImageB = NULL;
		m_outH = m_outW = 0;
	}
}

void CColorImageProcessingDoc::OnFreeMaskCalImage()
{
	// TODO: 여기에 구현 코드 추가.
	if (m_maskCalR != NULL) {
		OnFree2D(m_maskCalR, m_maskCalH);
		OnFree2D(m_maskCalG, m_maskCalH);
		OnFree2D(m_maskCalB, m_maskCalH);
		m_maskCalR = m_maskCalG = m_maskCalB = NULL;
		m_maskCalH = m_maskCalW = 0;
	}
}


void CColorImageProcessingDoc::OnEqualImage()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW,0);
	m_outImageG = OnMalloc2D(m_outH, m_outW,0);
	m_outImageB = OnMalloc2D(m_outH, m_outW,0);

	//**진짜 영상처리 알고리즘**
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			m_outImageR[i][k] = m_inImageR[i][k];
			m_outImageG[i][k] = m_inImageG[i][k];
			m_outImageB[i][k] = m_inImageB[i][k];
		}
	}
}


void CColorImageProcessingDoc::OnGrayScale()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW,0);
	m_outImageG = OnMalloc2D(m_outH, m_outW,0);
	m_outImageB = OnMalloc2D(m_outH, m_outW,0);
	double avg;
	//**진짜 영상처리 알고리즘**
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			avg = (m_inImageR[i][k] + m_inImageG[i][k] + m_inImageB[i][k]) / 3.0;
			m_outImageR[i][k] = m_outImageG[i][k] = m_outImageB[i][k] = (unsigned char)avg;

		}
	}
}


BOOL CColorImageProcessingDoc::OnSaveDocument(LPCTSTR lpszPathName)
{
	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
	if (m_outImageR == NULL)
		return FALSE;

	CImage image;
	image.Create(m_outW, m_outH, 32);

	unsigned char R, G, B;
	COLORREF px;

	for (int i = 0; i < m_outW; i++) {
		for (int k = 0; k < m_outH; k++) {
			R = m_outImageR[k][i];
			G = m_outImageG[k][i];
			B = m_outImageB[k][i];
			px = RGB(R, G, B);
			image.SetPixel(i, k, px);
		}
	}
	image.Save(lpszPathName, Gdiplus::ImageFormatPNG);
	MessageBox(NULL, L"저장", L"성공", NULL);
	return TRUE;
}


void CColorImageProcessingDoc::OnAddImage()
{
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		//기존 메모리 해제
		OnFreeOutImage();
		// TODO: 여기에 구현 코드 추가.

		//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		//메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW,0);
		m_outImageG = OnMalloc2D(m_outH, m_outW,0);
		m_outImageB = OnMalloc2D(m_outH, m_outW,0);
		int value = (int)dlg.m_constant;
		//**진짜 영상처리 알고리즘**
		
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				if (m_inImageR[i][k] + value >= 255) 
					m_outImageR[i][k] = 255;
				else if (m_inImageR[i][k] + value <= 0)
					m_outImageR[i][k] = 0;
				else
					m_outImageR[i][k]=m_inImageR[i][k] + value;
			}
		}
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				if (m_inImageG[i][k] + value >= 255)
					m_outImageG[i][k] = 255;
				else if (m_inImageG[i][k] + value <= 0)
					m_outImageG[i][k] = 0;
				else
					m_outImageG[i][k] = m_inImageG[i][k] + value;
			}
		}
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				if (m_inImageB[i][k] + value >= 255)
					m_outImageB[i][k] = 255;
				else if (m_inImageB[i][k] + value <= 0)
					m_outImageB[i][k] = 0;
				else
					m_outImageB[i][k] = m_inImageB[i][k] + value;
			}
		}
	}
}


void CColorImageProcessingDoc::OnOpImage()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW,0);
	m_outImageG = OnMalloc2D(m_outH, m_outW,0);
	m_outImageB = OnMalloc2D(m_outH, m_outW,0);

	//**진짜 영상처리 알고리즘**
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			m_outImageR[i][k] = 255-m_inImageR[i][k];
			m_outImageG[i][k] = 255-m_inImageG[i][k];
			m_outImageB[i][k] = 255-m_inImageB[i][k];
		}
	}
}


void CColorImageProcessingDoc::OnBlackImage()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	double avg;
	//**진짜 영상처리 알고리즘**
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			avg = (m_inImageR[i][k] + m_inImageG[i][k] + m_inImageB[i][k]) / 3.0;
			m_outImageR[i][k] = m_outImageG[i][k] = m_outImageB[i][k] = (unsigned char)avg;

		}
	}
	double hap = 0;
	double hapavg = 0;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			hap += m_outImageR[i][k];
		}
	}
	hapavg = hap / (m_inH * m_inW);
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			if (m_outImageR[i][k] > hapavg) {
				m_outImageR[i][k] = 255;
				m_outImageG[i][k] = 255;
				m_outImageB[i][k] = 255;
			}
			else if (m_outImageR[i][k] <= hapavg) {
				m_outImageR[i][k] = 0;
				m_outImageG[i][k] = 0;
				m_outImageB[i][k] = 0;
			}
		}
	}
	
}


void CColorImageProcessingDoc::OnChangeSatur()
{
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

	//**진짜 영상처리 알고리즘**
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			//HIS 모델 값
			//H(색상) : 0 ~ 360
			//S(채도) : 0.0 ~ 1.0
			//I(명도) : 0 ~ 255

			//RGB --> HSI
			double H, S, I;
			unsigned char R, G, B;

			R = m_inImageR[i][k];
			G = m_inImageG[i][k];
			B = m_inImageB[i][k];

			double* hsi = RGB2HSI(R, G, B);

			H = hsi[0];
			S = hsi[1];
			I = hsi[2];

			///채도(S) 흐리게
			S = S - 0.6;
			if (S < 0)
				S = 0.0;

			///HSI ---> RGB
			unsigned char* rgb = HSI2RGB(H, S, I);
			R = rgb[0];
			G = rgb[1];
			B = rgb[2];

			m_outImageR[i][k] = R;
			m_outImageG[i][k] = G;
			m_outImageB[i][k] = B;
		}
	}
}


double* CColorImageProcessingDoc::RGB2HSI(int R, int G, int B)
{
	// TODO: 여기에 구현 코드 추가.
	// TODO: 여기에 구현 코드 추가.
	double H, S, I;
	double* HSI = new double[3];
	double min_value, angle;
	I = (R + G + B) / 3.0; // 밝기
	if ((R == G) && (G == B)) { // 그레이
		S = 0.0;
		H = 0.0;
	}
	else {

		min_value = min(min(R, G), B); //최소값 추출
		angle = (R - 0.5 * G - 0.5 * B) / (double)sqrt((R - G) * (R - G) + (R - B) * (G - B));

		H = (double)acos(angle) * 57.29577951;
		S = 1.0f - (3.0 / (R + G + B)) * min_value;
	}
	if (B > G) H = 360. - H;

	HSI[0] = H;
	HSI[1] = S;
	HSI[2] = I;

	return HSI;
}


unsigned char* CColorImageProcessingDoc::HSI2RGB(double H, double S, double I)
{
	// TODO: 여기에 구현 코드 추가.
	double R, G, B;
	unsigned char* RGB = new unsigned char[3];
	double angle1, angle2, scale;

	if (I == 0.0) { // Black
		RGB[0] = 0;
		RGB[1] = 0;
		RGB[2] = 0;
		return RGB;
	}

	if (H <= 0.0) H += 360.0f;

	scale = 3.0 * I;
	if (H <= 120.0)
	{
		angle1 = H * 0.017453293;
		angle2 = (60.0 - H) * 0.017453293;
		B = (1.0 - S) / 3.0f;
		R = (double)(1.0 + (S * cos(angle1) / cos(angle2))) / 3.0;
		G = 1.0 - R - B;
		B *= scale;
		R *= scale;
		G *= scale;
	}


	else if ((H > 120.0) && (H <= 240.0)) {
		H -= 120.0;
		angle1 = H * 0.017453293;

		angle2 = (60.0 - H) * 0.017453293;
		R = (1.0 - S) / 3.0;
		G = (double)(1.0f + (S * cos(angle1) / cos(angle2))) / 3.0;
		B = 1.0 - R - G;
		R *= scale;
		G *= scale;
		B *= scale;
	}
	else {
		H -= 240.0;
		angle1 = H * 0.017453293;
		angle2 = (60.0 - H) * 0.017453293;
		G = (1.0f - S) / 3.0;
		B = (double)(1.0 + (S * cos(angle1) / cos(angle2))) / 3.0;
		R = 1.0 - G - B;

		R *= scale;
		G *= scale;
		B *= scale;
	}

	RGB[0] = (unsigned char)R;
	RGB[1] = (unsigned char)G;
	RGB[2] = (unsigned char)B;
	return RGB;
}

void CColorImageProcessingDoc::OnPickColor()
{
	CColorMinMax dlg;
	if (dlg.DoModal() == IDOK) {
		//기존 메모리 해제
		OnFreeOutImage();
		// TODO: 여기에 구현 코드 추가.

		//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		//메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
		//색상범위
		int min = (int)dlg.m_MinColor;
		int max = (int)dlg.m_MaxColor;
		//**진짜 영상처리 알고리즘**
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				//HIS 모델 값
				//H(색상) : 0 ~ 360
				//S(채도) : 0.0 ~ 1.0
				//I(명도) : 0 ~ 255

				//RGB --> HSI
				double H, S, I;
				unsigned char R, G, B;

				R = m_inImageR[i][k];
				G = m_inImageG[i][k];
				B = m_inImageB[i][k];

				double* hsi = RGB2HSI(R, G, B);
				H = hsi[0]; S = hsi[1]; I = hsi[2];

				///입력 색상 추출(H : 8~20)
				if (min <= H && H <= max) {
					m_outImageR[i][k] = m_inImageR[i][k];
					m_outImageG[i][k] = m_inImageG[i][k];
					m_outImageB[i][k] = m_inImageB[i][k];
				}
				else {
					double avg = (m_inImageR[i][k] + m_inImageG[i][k] + m_inImageB[i][k]) / 3.0;
					m_outImageR[i][k] = m_outImageG[i][k] = m_outImageB[i][k] = (unsigned char)avg;
				}

			}
		}
	}
}


void CColorImageProcessingDoc::OnOrImage()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.
	OnMalloc2DMaskCal();
	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

	//**진짜 영상처리 알고리즘**
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			m_outImageR[i][k] = m_inImageR[i][k] | m_maskCalR[i][k];
			m_outImageG[i][k] = m_inImageG[i][k] | m_maskCalG[i][k];
			m_outImageB[i][k] = m_inImageB[i][k] | m_maskCalB[i][k];
		}
	}
	//or계산 마스크 메모리 해제
	if (m_maskCalR != NULL) {
		OnFree2D(m_maskCalR, m_maskCalH);
		OnFree2D(m_maskCalG, m_maskCalH);
		OnFree2D(m_maskCalB, m_maskCalH);
		m_maskCalR = m_maskCalG = m_maskCalB = NULL;
		m_maskCalH = m_maskCalW = 0;
	}

}


void CColorImageProcessingDoc::OnMalloc2DMaskCal()
{
	// TODO: 여기에 구현 코드 추가.
	CFile File;
	CFileDialog orDlg(TRUE, NULL, NULL, OFN_HIDEREADONLY);
	if (orDlg.DoModal() == IDOK) {

		//기존 메모리 해제
		if (m_maskCalR != NULL) {
			OnFree2D(m_maskCalR, m_maskCalH);
			OnFree2D(m_maskCalG, m_maskCalH);
			OnFree2D(m_maskCalB, m_maskCalH);
			m_maskCalR = m_maskCalG = m_maskCalB = NULL;
			m_maskCalH = m_maskCalW = 0;
		}
		// TODO:  여기에 특수화된 작성 코드를 추가합니다.
		CImage image;
		image.Load(orDlg.GetPathName());
		//(중요!) 입력 영상 크기 알아내기~
		m_maskCalH = image.GetHeight();
		m_maskCalW = image.GetWidth();
		//메모리 할당
		m_maskCalR = OnMalloc2D(m_maskCalH, m_maskCalW, 0);
		m_maskCalG = OnMalloc2D(m_maskCalH, m_maskCalW, 0);
		m_maskCalB = OnMalloc2D(m_maskCalH, m_maskCalW, 0);
		//CImage의 객체값 --> 메모리
		COLORREF px;
		for (int i = 0; i < m_maskCalH; i++) {
			for (int k = 0; k < m_maskCalW; k++) {
				px = image.GetPixel(k, i);
				m_maskCalR[i][k] = GetRValue(px);
				m_maskCalG[i][k] = GetGValue(px);
				m_maskCalB[i][k] = GetBValue(px);
			}
		}
	}

}


void CColorImageProcessingDoc::OnAndImage()
{
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.
	OnMalloc2DMaskCal();
	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

	//**진짜 영상처리 알고리즘**
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			m_outImageR[i][k] = m_inImageR[i][k] & m_maskCalR[i][k];
			m_outImageG[i][k] = m_inImageG[i][k] & m_maskCalG[i][k];
			m_outImageB[i][k] = m_inImageB[i][k] & m_maskCalB[i][k];
		}
	}
	//and계산 마스크 메모리 해제
	if (m_maskCalR != NULL) {
		OnFree2D(m_maskCalR, m_maskCalH);
		OnFree2D(m_maskCalG, m_maskCalH);
		OnFree2D(m_maskCalB, m_maskCalH);
		m_maskCalR = m_maskCalG = m_maskCalB = NULL;
		m_maskCalH = m_maskCalW = 0;
	}
}


void CColorImageProcessingDoc::OnXorImage()
{
	// TODO: 여기에 구현 코드 추가.
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		//기존 메모리 해제
		OnFreeOutImage();
		// TODO: 여기에 구현 코드 추가.

		//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		//메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
		int value = (int)dlg.m_constant;
		//**진짜 영상처리 알고리즘**
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				m_outImageR[i][k] = m_inImageR[i][k] ^ value;
				m_outImageG[i][k] = m_inImageG[i][k] ^ value;
				m_outImageB[i][k] = m_inImageB[i][k] ^ value;
			}
		}
	
	
	}
}


void CColorImageProcessingDoc::OnInvalueImage()
{
	// TODO: 여기에 구현 코드 추가.
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
		OnFreeOutImage();
		// TODO: 여기에 구현 코드 추가.

		//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		//메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
		double avg;
		//**진짜 영상처리 알고리즘**
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				avg = (m_inImageR[i][k] + m_inImageG[i][k] + m_inImageB[i][k]) / 3.0;
				m_outImageR[i][k] = m_outImageG[i][k] = m_outImageB[i][k] = (unsigned char)avg;

			}
		}
		int value = (int)dlg.m_constant;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				if (m_outImageR[i][k] > value) {
					m_outImageR[i][k] = 255;
					m_outImageG[i][k] = 255;
					m_outImageB[i][k] = 255;
				}
				else if (m_outImageR[i][k] <= value) {
					m_outImageR[i][k] = 0;
					m_outImageG[i][k] = 0;
					m_outImageB[i][k] = 0;
				}
			}
		}
	}
}


void CColorImageProcessingDoc::OnZoomout()
{
	// TODO: 여기에 구현 코드 추가.
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		//기존 메모리 해제
		OnFreeOutImage();
		// TODO: 여기에 구현 코드 추가.
		int scale = (int)dlg.m_constant;
		//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = (m_inH/scale);
		m_outW = (m_inW/scale);
		//메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

		//**진짜 영상처리 알고리즘**
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				m_outImageR[i][k] = m_inImageR[i*scale][k*scale];
				m_outImageG[i][k] = m_inImageG[i*scale][k*scale];
				m_outImageB[i][k] = m_inImageB[i*scale][k*scale];
			}
		}
	}
}


void CColorImageProcessingDoc::OnZoomin()
{
	// TODO: 여기에 구현 코드 추가.
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		//기존 메모리 해제
		OnFreeOutImage();
		// TODO: 여기에 구현 코드 추가.
		int scale = (int)dlg.m_constant;
		//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = (m_inH * scale);
		m_outW = (m_inW * scale);
		//메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

		//**진짜 영상처리 알고리즘**
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				m_outImageR[i][k] = m_inImageR[i / scale][k / scale];
				m_outImageG[i][k] = m_inImageG[i / scale][k / scale];
				m_outImageB[i][k] = m_inImageB[i / scale][k / scale];
			}
		}
	}
}


void CColorImageProcessingDoc::OnMove()
{
	// TODO: 여기에 구현 코드 추가.
	CXYConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		//기존 메모리 해제
		OnFreeOutImage();
		// TODO: 여기에 구현 코드 추가.
		int xmove = (int)dlg.m_X;
		int ymove = (int)dlg.m_Y;
		//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH ;
		m_outW = m_inW;
		//메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

		//**진짜 영상처리 알고리즘**
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if ((0 <= i - xmove && i - xmove < m_outH) && (0 <= k - ymove && k - ymove < m_outW)) {
					m_outImageR[i][k] = m_inImageR[i - xmove][k - ymove];
					m_outImageG[i][k] = m_inImageG[i - xmove][k - ymove];
					m_outImageB[i][k] = m_inImageB[i - xmove][k - ymove];
				}
			}
		}
	}
}


void CColorImageProcessingDoc::OnRotate()
{
	// TODO: 여기에 구현 코드 추가.
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		//기존 메모리 해제
		OnFreeOutImage();
		// TODO: 여기에 구현 코드 추가.
		int degree = (int)dlg.m_constant;
		double radian = -degree * 3.141592 / 180.0;
		//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		//메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

		//**진짜 영상처리 알고리즘**
		int cx = m_inH / 2;
		int cy = m_inW / 2;

		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				int xd = i;
				int yd = k;

				int xs = (int)(cos(radian) * (xd - cx) + sin(radian) * (yd - cy)) + cx;
				int ys = (int)(-sin(radian) * (xd - cx) + cos(radian) * (yd - cy)) + cy;

				if ((0 <= xs && xs < m_outH) && (0 <= ys && ys < m_outW)) {
					m_outImageR[xd][yd] = m_inImageR[xs][ys];
					m_outImageG[xd][yd] = m_inImageG[xs][ys];
					m_outImageB[xd][yd] = m_inImageB[xs][ys];
				}
			}
		}
	}
}


void CColorImageProcessingDoc::OnZoomRotate()
{
	// TODO: 여기에 구현 코드 추가.
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		//기존 메모리 해제
		OnFreeOutImage();
		// TODO: 여기에 구현 코드 추가.
		int degree = (int)dlg.m_constant;
		double radian = -degree * 3.141592 / 180.0;
		double radian90 = 90 * 3.141592 / 180.0;
		//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = (int)(m_inW * OnDoubleABS(cos(radian90 + radian)) + (m_inH * (cos(radian)))); //outImage 배열의 크기를 돌린 각도에 맞게 증가
		m_outW = (int)(m_inH * OnDoubleABS(cos(radian90 + radian)) + (m_inW * (cos(radian))));

		//메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

		//**진짜 영상처리 알고리즘**
		int cx = m_inH / 2;
		int cy = m_inW / 2;

		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				int xd = i;
				int yd = k;

				int xs = (int)(cos(radian) * (xd - (m_outH / 2)) + sin(radian) * (yd - (m_outW / 2))) + cx;
				int ys = (int)(-sin(radian) * (xd - (m_outH / 2)) + cos(radian) * (yd - (m_outW / 2))) + cy;

				if ((0 <= xs && xs < m_inH) && (0 <= ys && ys < m_inW)) {
					m_outImageR[xd][yd] = m_inImageR[xs][ys];
					m_outImageG[xd][yd] = m_inImageG[xs][ys];
					m_outImageB[xd][yd] = m_inImageB[xs][ys];
				}
			}
		}
	}
}


double CColorImageProcessingDoc::OnDoubleABS(double value)//절대값 함수
{
	// TODO: 여기에 구현 코드 추가.
	if (value < 0.0) {
		value *= -1;
	}
	else {
		value;
	}
	return value;
}


void CColorImageProcessingDoc::OnUdmirroe()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

	//**진짜 영상처리 알고리즘**
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			m_outImageR[i][k] = m_inImageR[(m_inH-1)-i][k];
			m_outImageG[i][k] = m_inImageG[(m_inH - 1) - i][k];
			m_outImageB[i][k] = m_inImageB[(m_inH - 1) - i][k];
		}
	}
}


void CColorImageProcessingDoc::OnLrmirroe()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

	//**진짜 영상처리 알고리즘**
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			m_outImageR[i][k] = m_inImageR[i][(m_inW - 1) - k];
			m_outImageG[i][k] = m_inImageG[i][(m_inW - 1) - k];
			m_outImageB[i][k] = m_inImageB[i][(m_inW - 1) - k];
		}
	}
}


void CColorImageProcessingDoc::OnEmboss()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	double mask[3][3] = { {-1.0, 0.0, 0.0}, // 엠보싱 마스크
						  { 0.0, 0.0, 0.0},
						  { 0.0, 0.0, 1.0} };
	//임시 메모리 할당(실수형)
	unsigned char** tmpInImageR = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageG = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageB = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpOutImageR = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageG = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageB = OnMalloc2D(m_outH, m_outW, 0);

	// 입력 이미지 --> 임시 입력 이미지
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	// *** 회선 연산 ***
	double SR,SG,SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			// 마스크(3x3) 와 한점을 중심으로한 3x3을 곱하기
			SR = SG = SB = 0.0; // 마스크 9개와 입력값 9개를 각각 곱해서 합한 값.

			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++) {
					SR += (double)tmpInImageR[i + m][k + n] * mask[m][n];
					SG += (double)tmpInImageG[i + m][k + n] * mask[m][n];
					SB += (double)tmpInImageB[i + m][k + n] * mask[m][n];
				}

			tmpOutImageR[i][k] = SR;
			tmpOutImageG[i][k] = SG;
			tmpOutImageB[i][k] = SB;
		}
	}
	// 후처리 (마스크 값의 합계에 따라서...)
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			tmpOutImageR[i][k] += 127.0;
			tmpOutImageG[i][k] += 127.0;
			tmpOutImageB[i][k] += 127.0;
		}

	// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];
		}
	}
}


void CColorImageProcessingDoc::OnBlur()
{
	// TODO: 여기에 구현 코드 추가.
	CBlurConstant dlg;
	if (dlg.DoModal() == IDOK) {
		//기존 메모리 해제
		OnFreeOutImage();
		// TODO: 여기에 구현 코드 추가.

		//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		//메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
		m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
		int maskSize = (int)dlg.m_blurconstant;
		m_mask = OnMalloc2DDouble(maskSize, maskSize, 1.0 / (maskSize * maskSize)); // 블러링 마스크
		//임시 메모리 할당(실수형)
		unsigned char** tmpInImageR = OnMalloc2D(m_inH + maskSize - 1, m_inW + maskSize - 1 + 2, 127);
		unsigned char** tmpInImageG = OnMalloc2D(m_inH + maskSize - 1, m_inW + maskSize - 1 + 2, 127);
		unsigned char** tmpInImageB = OnMalloc2D(m_inH + maskSize - 1, m_inW + maskSize - 1 + 2, 127);
		unsigned char** tmpOutImageR = OnMalloc2D(m_outH, m_outW, 0);
		unsigned char** tmpOutImageG = OnMalloc2D(m_outH, m_outW, 0);
		unsigned char** tmpOutImageB = OnMalloc2D(m_outH, m_outW, 0);

		// 입력 이미지 --> 임시 입력 이미지
		for (int i = 0; i < m_inH; i++)
			for (int k = 0; k < m_inW; k++) {
				tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
				tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
				tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
			}

		// *** 회선 연산 ***
		double SR, SG, SB;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				// 마스크(3x3) 와 한점을 중심으로한 3x3을 곱하기
				SR = SG = SB = 0.0; // 마스크 9개와 입력값 9개를 각각 곱해서 합한 값.

				for (int m = 0; m < maskSize; m++)
					for (int n = 0; n < maskSize; n++) {
						SR += (double)tmpInImageR[i + m][k + n] * m_mask[m][n];
						SG += (double)tmpInImageG[i + m][k + n] * m_mask[m][n];
						SB += (double)tmpInImageB[i + m][k + n] * m_mask[m][n];
					}

				tmpOutImageR[i][k] = SR;
				tmpOutImageG[i][k] = SG;
				tmpOutImageB[i][k] = SB;
			}
		}

		// 임시 출력 영상--> 출력 영상. 
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if (tmpOutImageR[i][k] < 0.0)
					m_outImageR[i][k] = 0;
				else if (tmpOutImageR[i][k] > 255.0)
					m_outImageR[i][k] = 255;
				else
					m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];
			}
		}
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if (tmpOutImageG[i][k] < 0.0)
					m_outImageG[i][k] = 0;
				else if (tmpOutImageG[i][k] > 255.0)
					m_outImageG[i][k] = 255;
				else
					m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];
			}
		}
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if (tmpOutImageB[i][k] < 0.0)
					m_outImageB[i][k] = 0;
				else if (tmpOutImageB[i][k] > 255.0)
					m_outImageB[i][k] = 255;
				else
					m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];
			}
		}
	}
}


double** CColorImageProcessingDoc::OnMalloc2DDouble(int h, int w, double initValue)
{
	// TODO: 여기에 구현 코드 추가.
	double** retMemory;
	retMemory = new double* [h];
	for (int i = 0; i < h; i++)
		retMemory[i] = new double[w];
	for (int i = 0; i < h; i++) {
		for (int k = 0; k < w; k++) {
			retMemory[i][k] = initValue;
		}
	}
	return retMemory;
}


void CColorImageProcessingDoc::OnSharpning()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	double mask[3][3] = { {-1.0, -1.0, -1.0}, // 샤프닝 마스크
						  {-1.0, 9.0 , -1.0},
						  {-1.0, -1.0, -1.0} };
	//임시 메모리 할당(실수형)
	unsigned char** tmpInImageR = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageG = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageB = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpOutImageR = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageG = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageB = OnMalloc2D(m_outH, m_outW, 0);

	// 입력 이미지 --> 임시 입력 이미지
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	// *** 회선 연산 ***
	double SR, SG, SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			// 마스크(3x3) 와 한점을 중심으로한 3x3을 곱하기
			SR = SG = SB = 0.0; // 마스크 9개와 입력값 9개를 각각 곱해서 합한 값.

			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++) {
					SR += (double)tmpInImageR[i + m][k + n] * mask[m][n];
					SG += (double)tmpInImageG[i + m][k + n] * mask[m][n];
					SB += (double)tmpInImageB[i + m][k + n] * mask[m][n];
				}

			tmpOutImageR[i][k] = SR;
			tmpOutImageG[i][k] = SG;
			tmpOutImageB[i][k] = SB;
		}
	}

	// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];
		}
	}
}

void CColorImageProcessingDoc::OnSharpningHsi()
{
	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	// ** 진짜 영상처리 알고리즘 **
	const int MSIZE = 3;
	double mask[MSIZE][MSIZE] = {  // 엠보싱 마스크
		{ -1.0, -1.0, -1.0 },
		{  -1.0, 9.0, -1.0 },
		{  -1.0, -1.0, -1.0 } };

	// 임시 메모리 할당
	double** tmpInImageR, ** tmpInImageG, ** tmpInImageB, ** tmpOutImageR, ** tmpOutImageG, ** tmpOutImageB;
	double** tmpInImageH, ** tmpInImageS, ** tmpInImageI;
	tmpInImageR = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageG = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageB = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);

	tmpInImageH = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageS = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageI = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);

	tmpOutImageR = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageG = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageB = OnMalloc2DDouble(m_outH, m_outW, 0);


	// 입력메모리 --> 임시입력메모리
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	///////// RGB 모델 --> HSI 모델 ///////////////
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double* hsi;
			unsigned char R, G, B;
			R = tmpInImageR[i][k]; G = tmpInImageG[i][k]; B = tmpInImageB[i][k];
			hsi = RGB2HSI(R, G, B);

			double H, S, I;
			H = hsi[0]; S = hsi[1]; I = hsi[2];
			tmpInImageH[i][k] = H; tmpInImageS[i][k] = S; tmpInImageI[i][k] = I;
		}
	}
	// *** 회선 연산 : 마스크로 긁어가면서 계산하기.	
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double S_VALUE = 0.0;
			for (int m = 0; m < MSIZE; m++)
				for (int n = 0; n < MSIZE; n++)
					S_VALUE += tmpInImageI[i + m][k + n] * mask[m][n];
			if (S_VALUE >= 255.0) {
				tmpInImageI[i][k] = 255.0;
			}
			else if (S_VALUE <= 0) {
				tmpInImageI[i][k] = 0.0;
			}
			else {
				tmpInImageI[i][k] = S_VALUE;
			}
		}
	}

	

	////// HSI --> RGB ////////
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			unsigned char* rgb;
			double H, S, I;

			H = tmpInImageH[i][k]; S = tmpInImageS[i][k]; I = tmpInImageI[i][k];

			rgb = HSI2RGB(H, S, I);
			tmpOutImageR[i][k] = rgb[0]; tmpOutImageG[i][k] = rgb[1]; tmpOutImageB[i][k] = rgb[2];
		}


	// 임시 출력 이미지 ---> 출력 이미지
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];

			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];

			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];

		}


	// 임시 메모리 해제
	OnFree2DDouble(tmpInImageR, m_inH + 2);
	OnFree2DDouble(tmpInImageG, m_inH + 2);
	OnFree2DDouble(tmpInImageB, m_inH + 2);
	OnFree2DDouble(tmpInImageH, m_inH + 2);
	OnFree2DDouble(tmpInImageS, m_inH + 2);
	OnFree2DDouble(tmpInImageI, m_inH + 2);
	OnFree2DDouble(tmpOutImageR, m_outH);
	OnFree2DDouble(tmpOutImageG, m_outH);
	OnFree2DDouble(tmpOutImageB, m_outH);
}

void CColorImageProcessingDoc::OnHighSharpning()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	double mask[3][3] = { {-1.0/9, -1.0/9, -1.0/9}, // 샤프닝 마스크
						  {-1.0/9, 8.0/9 , -1.0/9},
						  {-1.0/9, -1.0/9, -1.0/9} };
	//임시 메모리 할당(실수형)
	unsigned char** tmpInImageR = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageG = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageB = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpOutImageR = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageG = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageB = OnMalloc2D(m_outH, m_outW, 0);

	// 입력 이미지 --> 임시 입력 이미지
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	// *** 회선 연산 ***
	double SR, SG, SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			// 마스크(3x3) 와 한점을 중심으로한 3x3을 곱하기
			SR = SG = SB = 0.0; // 마스크 9개와 입력값 9개를 각각 곱해서 합한 값.

			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++) {
					SR += (double)tmpInImageR[i + m][k + n] * mask[m][n];
					SG += (double)tmpInImageG[i + m][k + n] * mask[m][n];
					SB += (double)tmpInImageB[i + m][k + n] * mask[m][n];
				}

			tmpOutImageR[i][k] = SR;
			tmpOutImageG[i][k] = SG;
			tmpOutImageB[i][k] = SB;
		}
	}
	// 후처리 (마스크 값의 합계에 따라서...)
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			tmpOutImageR[i][k] += 127.0;
			tmpOutImageG[i][k] += 127.0;
			tmpOutImageB[i][k] += 127.0;
		}

	// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];
		}
	}
}

void CColorImageProcessingDoc::OnHighSharpningHsi()
{
	// TODO: 여기에 구현 코드 추가.
	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	// ** 진짜 영상처리 알고리즘 **
	const int MSIZE = 3;
	double mask[MSIZE][MSIZE] = { {-1.0 / 9, -1.0 / 9, -1.0 / 9}, // 샤프닝 마스크
						  {-1.0 / 9, 8.0 / 9 , -1.0 / 9},
						  {-1.0 / 9, -1.0 / 9, -1.0 / 9} };

	// 임시 메모리 할당
	double** tmpInImageR, ** tmpInImageG, ** tmpInImageB, ** tmpOutImageR, ** tmpOutImageG, ** tmpOutImageB;
	double** tmpInImageH, ** tmpInImageS, ** tmpInImageI;
	tmpInImageR = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageG = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageB = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);

	tmpInImageH = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageS = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageI = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);

	tmpOutImageR = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageG = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageB = OnMalloc2DDouble(m_outH, m_outW, 0);


	// 입력메모리 --> 임시입력메모리
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	///////// RGB 모델 --> HSI 모델 ///////////////
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double* hsi;
			unsigned char R, G, B;
			R = tmpInImageR[i][k]; G = tmpInImageG[i][k]; B = tmpInImageB[i][k];
			hsi = RGB2HSI(R, G, B);

			double H, S, I;
			H = hsi[0]; S = hsi[1]; I = hsi[2];
			tmpInImageH[i][k] = H; tmpInImageS[i][k] = S; tmpInImageI[i][k] = I;
		}
	}
	// *** 회선 연산 : 마스크로 긁어가면서 계산하기.	
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double S_VALUE = 0.0;
			for (int m = 0; m < MSIZE; m++)
				for (int n = 0; n < MSIZE; n++)
					S_VALUE += tmpInImageI[i + m][k + n] * mask[m][n];
			tmpInImageI[i][k] = S_VALUE;
		}
	}

	// 후처리 (마스크의 합계에 따라서 127을 더할지 결정)
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageI[i][k] += 127;
		}

	////// HSI --> RGB ////////
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			unsigned char* rgb;
			double H, S, I;

			H = tmpInImageH[i][k]; S = tmpInImageS[i][k]; I = tmpInImageI[i][k];

			rgb = HSI2RGB(H, S, I);
			tmpOutImageR[i][k] = rgb[0]; tmpOutImageG[i][k] = rgb[1]; tmpOutImageB[i][k] = rgb[2];
		}


	// 임시 출력 이미지 ---> 출력 이미지
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];

			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];

			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];

		}


	// 임시 메모리 해제
	OnFree2DDouble(tmpInImageR, m_inH + 2);
	OnFree2DDouble(tmpInImageG, m_inH + 2);
	OnFree2DDouble(tmpInImageB, m_inH + 2);
	OnFree2DDouble(tmpInImageH, m_inH + 2);
	OnFree2DDouble(tmpInImageS, m_inH + 2);
	OnFree2DDouble(tmpInImageI, m_inH + 2);
	OnFree2DDouble(tmpOutImageR, m_outH);
	OnFree2DDouble(tmpOutImageG, m_outH);
	OnFree2DDouble(tmpOutImageB, m_outH);
}

void CColorImageProcessingDoc::OnHorEdge()
{
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	double mask[3][3] = { {0 , -1 , 0 }, // 수평 엣지검출 마스크
						  {0 , 1 , 0},
						  {0 , 0 , 0} };
	//임시 메모리 할당(실수형)
	unsigned char** tmpInImageR = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageG = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageB = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpOutImageR = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageG = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageB = OnMalloc2D(m_outH, m_outW, 0);

	// 입력 이미지 --> 임시 입력 이미지
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	// *** 회선 연산 ***
	double SR, SG, SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			// 마스크(3x3) 와 한점을 중심으로한 3x3을 곱하기
			SR = SG = SB = 0.0; // 마스크 9개와 입력값 9개를 각각 곱해서 합한 값.

			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++) {
					SR += (double)tmpInImageR[i + m][k + n] * mask[m][n];
					SG += (double)tmpInImageG[i + m][k + n] * mask[m][n];
					SB += (double)tmpInImageB[i + m][k + n] * mask[m][n];
				}

			tmpOutImageR[i][k] = SR;
			tmpOutImageG[i][k] = SG;
			tmpOutImageB[i][k] = SB;
		}
	}
	// 후처리 (마스크 값의 합계에 따라서...)
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			tmpOutImageR[i][k] += 127.0;
			tmpOutImageG[i][k] += 127.0;
			tmpOutImageB[i][k] += 127.0;
		}

	// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];
		}
	}
}

void CColorImageProcessingDoc::OnHoredgeHsi()
{
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	// ** 진짜 영상처리 알고리즘 **
	const int MSIZE = 3;
	double mask[MSIZE][MSIZE] = { {0 , -1 , 0 }, // 수평 엣지검출 마스크
						  {0 , 1 , 0},
						  {0 , 0 , 0} };

	// 임시 메모리 할당
	double** tmpInImageR, ** tmpInImageG, ** tmpInImageB, ** tmpOutImageR, ** tmpOutImageG, ** tmpOutImageB;
	double** tmpInImageH, ** tmpInImageS, ** tmpInImageI;
	tmpInImageR = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageG = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageB = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);

	tmpInImageH = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageS = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageI = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);

	tmpOutImageR = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageG = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageB = OnMalloc2DDouble(m_outH, m_outW, 0);


	// 입력메모리 --> 임시입력메모리
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	///////// RGB 모델 --> HSI 모델 ///////////////
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double* hsi;
			unsigned char R, G, B;
			R = tmpInImageR[i][k]; G = tmpInImageG[i][k]; B = tmpInImageB[i][k];
			hsi = RGB2HSI(R, G, B);

			double H, S, I;
			H = hsi[0]; S = hsi[1]; I = hsi[2];
			tmpInImageH[i][k] = H; tmpInImageS[i][k] = S; tmpInImageI[i][k] = I;
		}
	}
	// *** 회선 연산 : 마스크로 긁어가면서 계산하기.	
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double S_VALUE = 0.0;
			for (int m = 0; m < MSIZE; m++)
				for (int n = 0; n < MSIZE; n++)
					S_VALUE += tmpInImageI[i + m][k + n] * mask[m][n];
			tmpInImageI[i][k] = S_VALUE;
		}
	}

	// 후처리 (마스크의 합계에 따라서 127을 더할지 결정)
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageI[i][k] += 127;
		}

	////// HSI --> RGB ////////
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			unsigned char* rgb;
			double H, S, I;

			H = tmpInImageH[i][k]; S = tmpInImageS[i][k]; I = tmpInImageI[i][k];

			rgb = HSI2RGB(H, S, I);
			tmpOutImageR[i][k] = rgb[0]; tmpOutImageG[i][k] = rgb[1]; tmpOutImageB[i][k] = rgb[2];
		}


	// 임시 출력 이미지 ---> 출력 이미지
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];

			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];

			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];

		}


	// 임시 메모리 해제
	OnFree2DDouble(tmpInImageR, m_inH + 2);
	OnFree2DDouble(tmpInImageG, m_inH + 2);
	OnFree2DDouble(tmpInImageB, m_inH + 2);
	OnFree2DDouble(tmpInImageH, m_inH + 2);
	OnFree2DDouble(tmpInImageS, m_inH + 2);
	OnFree2DDouble(tmpInImageI, m_inH + 2);
	OnFree2DDouble(tmpOutImageR, m_outH);
	OnFree2DDouble(tmpOutImageG, m_outH);
	OnFree2DDouble(tmpOutImageB, m_outH);
}


void CColorImageProcessingDoc::OnVerEdge()
{
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	double mask[3][3] = { {0 , 0 , 0 }, // 수직 엣지검출 마스크
						  {-1 , 1 , 0},
						  {0 , 0 , 0} };
	//임시 메모리 할당(실수형)
	unsigned char** tmpInImageR = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageG = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageB = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpOutImageR = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageG = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageB = OnMalloc2D(m_outH, m_outW, 0);

	// 입력 이미지 --> 임시 입력 이미지
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	// *** 회선 연산 ***
	double SR, SG, SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			// 마스크(3x3) 와 한점을 중심으로한 3x3을 곱하기
			SR = SG = SB = 0.0; // 마스크 9개와 입력값 9개를 각각 곱해서 합한 값.

			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++) {
					SR += (double)tmpInImageR[i + m][k + n] * mask[m][n];
					SG += (double)tmpInImageG[i + m][k + n] * mask[m][n];
					SB += (double)tmpInImageB[i + m][k + n] * mask[m][n];
				}

			tmpOutImageR[i][k] = SR;
			tmpOutImageG[i][k] = SG;
			tmpOutImageB[i][k] = SB;
		}
	}
	// 후처리 (마스크 값의 합계에 따라서...)
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			tmpOutImageR[i][k] += 127.0;
			tmpOutImageG[i][k] += 127.0;
			tmpOutImageB[i][k] += 127.0;
		}

	// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];
		}
	}
}

void CColorImageProcessingDoc::OnVeredgeHsi()
{
	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	// ** 진짜 영상처리 알고리즘 **
	const int MSIZE = 3;
	double mask[MSIZE][MSIZE] = { {0 , 0 , 0 }, // 수직 엣지검출 마스크
						  {-1 , 1 , 0},
						  {0 , 0 , 0} };

	// 임시 메모리 할당
	double** tmpInImageR, ** tmpInImageG, ** tmpInImageB, ** tmpOutImageR, ** tmpOutImageG, ** tmpOutImageB;
	double** tmpInImageH, ** tmpInImageS, ** tmpInImageI;
	tmpInImageR = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageG = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageB = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);

	tmpInImageH = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageS = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageI = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);

	tmpOutImageR = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageG = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageB = OnMalloc2DDouble(m_outH, m_outW, 0);


	// 입력메모리 --> 임시입력메모리
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	///////// RGB 모델 --> HSI 모델 ///////////////
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double* hsi;
			unsigned char R, G, B;
			R = tmpInImageR[i][k]; G = tmpInImageG[i][k]; B = tmpInImageB[i][k];
			hsi = RGB2HSI(R, G, B);

			double H, S, I;
			H = hsi[0]; S = hsi[1]; I = hsi[2];
			tmpInImageH[i][k] = H; tmpInImageS[i][k] = S; tmpInImageI[i][k] = I;
		}
	}
	// *** 회선 연산 : 마스크로 긁어가면서 계산하기.	
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double S_VALUE = 0.0;
			for (int m = 0; m < MSIZE; m++)
				for (int n = 0; n < MSIZE; n++)
					S_VALUE += tmpInImageI[i + m][k + n] * mask[m][n];
			tmpInImageI[i][k] = S_VALUE;
		}
	}

	// 후처리 (마스크의 합계에 따라서 127을 더할지 결정)
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageI[i][k] += 127;
		}

	////// HSI --> RGB ////////
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			unsigned char* rgb;
			double H, S, I;

			H = tmpInImageH[i][k]; S = tmpInImageS[i][k]; I = tmpInImageI[i][k];

			rgb = HSI2RGB(H, S, I);
			tmpOutImageR[i][k] = rgb[0]; tmpOutImageG[i][k] = rgb[1]; tmpOutImageB[i][k] = rgb[2];
		}


	// 임시 출력 이미지 ---> 출력 이미지
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];

			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];

			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];

		}


	// 임시 메모리 해제
	OnFree2DDouble(tmpInImageR, m_inH + 2);
	OnFree2DDouble(tmpInImageG, m_inH + 2);
	OnFree2DDouble(tmpInImageB, m_inH + 2);
	OnFree2DDouble(tmpInImageH, m_inH + 2);
	OnFree2DDouble(tmpInImageS, m_inH + 2);
	OnFree2DDouble(tmpInImageI, m_inH + 2);
	OnFree2DDouble(tmpOutImageR, m_outH);
	OnFree2DDouble(tmpOutImageG, m_outH);
	OnFree2DDouble(tmpOutImageB, m_outH);
}


void CColorImageProcessingDoc::OnSimCal()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

	//임시 메모리 할당(실수형)
	unsigned char** tmpInImageR = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageG = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageB = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpOutImageR = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageG = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageB = OnMalloc2D(m_outH, m_outW, 0);

	// 입력 이미지 --> 임시 입력 이미지
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	// *** 회선 연산 ***
	double SR, SG, SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			// 마스크(3x3) 와 한점을 중심으로한 3x3을 곱하기
			SR = SG = SB = 0.0; // 마스크 9개와 입력값 9개를 각각 곱해서 합한 값.

			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++) {
					if (OnDoubleABS(tmpInImageR[i + 1][k + 1] - tmpInImageR[i + m][k + n]) >= SR) {
						SR = OnDoubleABS(tmpInImageR[i + 1][k + 1] - tmpInImageR[i + m][k + n]);
					}
					else if (OnDoubleABS(tmpInImageG[i + 1][k + 1] - tmpInImageG[i + m][k + n]) >= SG) {
						SG = OnDoubleABS(tmpInImageG[i + 1][k + 1] - tmpInImageG[i + m][k + n]);
					}
					else if (OnDoubleABS(tmpInImageB[i + 1][k + 1] - tmpInImageB[i + m][k + n]) >= SB) {
						SB = OnDoubleABS(tmpInImageB[i + 1][k + 1] - tmpInImageB[i + m][k + n]);
					}
				}

			tmpOutImageR[i][k] = SR;
			tmpOutImageG[i][k] = SG;
			tmpOutImageB[i][k] = SB;
		}
	}

	// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];
		}
	}
}

void CColorImageProcessingDoc::OnSimcalHsi()
{
	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	// ** 진짜 영상처리 알고리즘 **

	// 임시 메모리 할당
	double** tmpInImageR, ** tmpInImageG, ** tmpInImageB, ** tmpOutImageR, ** tmpOutImageG, ** tmpOutImageB;
	double** tmpInImageH, ** tmpInImageS, ** tmpInImageI;
	tmpInImageR = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageG = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageB = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);

	tmpInImageH = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageS = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageI = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);

	tmpOutImageR = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageG = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageB = OnMalloc2DDouble(m_outH, m_outW, 0);


	// 입력메모리 --> 임시입력메모리
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	///////// RGB 모델 --> HSI 모델 ///////////////
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double* hsi;
			unsigned char R, G, B;
			R = tmpInImageR[i][k]; G = tmpInImageG[i][k]; B = tmpInImageB[i][k];
			hsi = RGB2HSI(R, G, B);

			double H, S, I;
			H = hsi[0]; S = hsi[1]; I = hsi[2];
			tmpInImageH[i][k] = H; tmpInImageS[i][k] = S; tmpInImageI[i][k] = I;
		}
	}
	// *** 회선 연산 : 마스크로 긁어가면서 계산하기.	
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double S_VALUE = 0.0;
			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++)
					if (OnDoubleABS(tmpInImageI[i + 1][k + 1] - tmpInImageI[i + m][k + n]) >= S_VALUE) {
						S_VALUE = OnDoubleABS(tmpInImageI[i + 1][k + 1] - tmpInImageI[i + m][k + n]);
					}
			tmpInImageI[i][k] = S_VALUE;
		}
	}

	// 후처리 (마스크의 합계에 따라서 127을 더할지 결정)
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageI[i][k] += 127;
		}

	////// HSI --> RGB ////////
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			unsigned char* rgb;
			double H, S, I;

			H = tmpInImageH[i][k]; S = tmpInImageS[i][k]; I = tmpInImageI[i][k];

			rgb = HSI2RGB(H, S, I);
			tmpOutImageR[i][k] = rgb[0]; tmpOutImageG[i][k] = rgb[1]; tmpOutImageB[i][k] = rgb[2];
		}


	// 임시 출력 이미지 ---> 출력 이미지
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];

			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];

			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];

		}


	// 임시 메모리 해제
	OnFree2DDouble(tmpInImageR, m_inH + 2);
	OnFree2DDouble(tmpInImageG, m_inH + 2);
	OnFree2DDouble(tmpInImageB, m_inH + 2);
	OnFree2DDouble(tmpInImageH, m_inH + 2);
	OnFree2DDouble(tmpInImageS, m_inH + 2);
	OnFree2DDouble(tmpInImageI, m_inH + 2);
	OnFree2DDouble(tmpOutImageR, m_outH);
	OnFree2DDouble(tmpOutImageG, m_outH);
	OnFree2DDouble(tmpOutImageB, m_outH);
}

void CColorImageProcessingDoc::OnDivCal()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

	//임시 메모리 할당(실수형)
	unsigned char** tmpInImageR = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageG = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpInImageB = OnMalloc2D(m_inH + 2, m_inW + 2, 127);
	unsigned char** tmpOutImageR = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageG = OnMalloc2D(m_outH, m_outW, 0);
	unsigned char** tmpOutImageB = OnMalloc2D(m_outH, m_outW, 0);

	// 입력 이미지 --> 임시 입력 이미지
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	// *** 회선 연산 ***
	double mask4[4] = { 0, };
	double max;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			// 마스크(3x3) 와 한점을 중심으로한 3x3을 곱하기
			max = 0.0; // 차연산의 max값

			mask4[0] = OnDoubleABS(tmpInImageR[i][k] - tmpInImageR[i + 2][k + 2]);
			mask4[1] = OnDoubleABS(tmpInImageR[i][k + 1] - tmpInImageR[i + 2][k + 1]);
			mask4[2] = OnDoubleABS(tmpInImageR[i][k + 2] - tmpInImageR[i + 2][k]);
			mask4[3] = OnDoubleABS(tmpInImageR[i + 1][k] - tmpInImageR[i + 1][k + 2]);
			for (int i = 0; i < 4; i++) {
				if (mask4[i] >= max) {
					max = mask4[i];
				}
			}
			tmpOutImageR[i][k] = max;

			max = 0.0; // 차연산의 max값

			mask4[0] = OnDoubleABS(tmpInImageG[i][k] - tmpInImageG[i + 2][k + 2]);
			mask4[1] = OnDoubleABS(tmpInImageG[i][k + 1] - tmpInImageG[i + 2][k + 1]);
			mask4[2] = OnDoubleABS(tmpInImageG[i][k + 2] - tmpInImageG[i + 2][k]);
			mask4[3] = OnDoubleABS(tmpInImageG[i + 1][k] - tmpInImageG[i + 1][k + 2]);
			for (int i = 0; i < 4; i++) {
				if (mask4[i] >= max) {
					max = mask4[i];
				}
			}
			tmpOutImageG[i][k] = max;

			max = 0.0; // 차연산의 max값

			mask4[0] = OnDoubleABS(tmpInImageB[i][k] - tmpInImageB[i + 2][k + 2]);
			mask4[1] = OnDoubleABS(tmpInImageB[i][k + 1] - tmpInImageB[i + 2][k + 1]);
			mask4[2] = OnDoubleABS(tmpInImageB[i][k + 2] - tmpInImageB[i + 2][k]);
			mask4[3] = OnDoubleABS(tmpInImageB[i + 1][k] - tmpInImageB[i + 1][k + 2]);
			for (int i = 0; i < 4; i++) {
				if (mask4[i] >= max) {
					max = mask4[i];
				}
			}
			tmpOutImageB[i][k] = max;
		}
	}

	// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];
		}
	}
}

void CColorImageProcessingDoc::OnDivcalHsi()
{
	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	// ** 진짜 영상처리 알고리즘 **

	// 임시 메모리 할당
	double** tmpInImageR, ** tmpInImageG, ** tmpInImageB, ** tmpOutImageR, ** tmpOutImageG, ** tmpOutImageB;
	double** tmpInImageH, ** tmpInImageS, ** tmpInImageI;
	tmpInImageR = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageG = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);
	tmpInImageB = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 127);

	tmpInImageH = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageS = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);
	tmpInImageI = OnMalloc2DDouble(m_inH + 2, m_inW + 2, 0);

	tmpOutImageR = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageG = OnMalloc2DDouble(m_outH, m_outW, 0);
	tmpOutImageB = OnMalloc2DDouble(m_outH, m_outW, 0);


	// 입력메모리 --> 임시입력메모리
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	///////// RGB 모델 --> HSI 모델 ///////////////
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double* hsi;
			unsigned char R, G, B;
			R = tmpInImageR[i][k]; G = tmpInImageG[i][k]; B = tmpInImageB[i][k];
			hsi = RGB2HSI(R, G, B);

			double H, S, I;
			H = hsi[0]; S = hsi[1]; I = hsi[2];
			tmpInImageH[i][k] = H; tmpInImageS[i][k] = S; tmpInImageI[i][k] = I;
		}
	}
	// *** 회선 연산 : 마스크로 긁어가면서 계산하기.
	double mask4[4] = { 0, };
	double max;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			max = 0.0; // 차연산의 max값

			mask4[0] = OnDoubleABS(tmpInImageI[i][k] - tmpInImageI[i + 2][k + 2]);
			mask4[1] = OnDoubleABS(tmpInImageI[i][k + 1] - tmpInImageI[i + 2][k + 1]);
			mask4[2] = OnDoubleABS(tmpInImageI[i][k + 2] - tmpInImageI[i + 2][k]);
			mask4[3] = OnDoubleABS(tmpInImageI[i + 1][k] - tmpInImageI[i + 1][k + 2]);
			for (int i = 0; i < 4; i++) {
				if (mask4[i] >= max) {
					max = mask4[i];
				}
			}
			tmpInImageI[i][k] = max;
		}
	}

	// 후처리 (마스크의 합계에 따라서 127을 더할지 결정)
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageI[i][k] += 127;
		}

	////// HSI --> RGB ////////
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			unsigned char* rgb;
			double H, S, I;

			H = tmpInImageH[i][k]; S = tmpInImageS[i][k]; I = tmpInImageI[i][k];

			rgb = HSI2RGB(H, S, I);
			tmpOutImageR[i][k] = rgb[0]; tmpOutImageG[i][k] = rgb[1]; tmpOutImageB[i][k] = rgb[2];
		}


	// 임시 출력 이미지 ---> 출력 이미지
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];

			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];

			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];

		}


	// 임시 메모리 해제
	OnFree2DDouble(tmpInImageR, m_inH + 2);
	OnFree2DDouble(tmpInImageG, m_inH + 2);
	OnFree2DDouble(tmpInImageB, m_inH + 2);
	OnFree2DDouble(tmpInImageH, m_inH + 2);
	OnFree2DDouble(tmpInImageS, m_inH + 2);
	OnFree2DDouble(tmpInImageI, m_inH + 2);
	OnFree2DDouble(tmpOutImageR, m_outH);
	OnFree2DDouble(tmpOutImageG, m_outH);
	OnFree2DDouble(tmpOutImageB, m_outH);
}

void CColorImageProcessingDoc::OnStreatch()
{
	// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);

	//**진짜 영상처리 알고리즘**
	//R
	int high = m_inImageR[0][0], low = m_inImageR[0][0];
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			if (m_inImageR[i][k] < low)
				low = m_inImageR[i][k];
			if (m_inImageR[i][k] > high)
				high = m_inImageR[i][k];
		}
	}
	int old, new1;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			old = m_inImageR[i][k];
			new1 = (int)((double)(old - low) / (double)(high - low) * 255.0);

			if (new1 > 255)
				new1 = 255;
			if (new1 < 0)
				new1 = 0;
			m_outImageR[i][k] = new1;
		}
	}
	//G
	high = m_inImageG[0][0], low = m_inImageG[0][0];
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			if (m_inImageG[i][k] < low)
				low = m_inImageG[i][k];
			if (m_inImageG[i][k] > high)
				high = m_inImageG[i][k];
		}
	}
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			old = m_inImageG[i][k];
			new1 = (int)((double)(old - low) / (double)(high - low) * 255.0);

			if (new1 > 255)
				new1 = 255;
			if (new1 < 0)
				new1 = 0;
			m_outImageG[i][k] = new1;
		}
	}
	//B
	high = m_inImageB[0][0], low = m_inImageB[0][0];
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			if (m_inImageB[i][k] < low)
				low = m_inImageB[i][k];
			if (m_inImageB[i][k] > high)
				high = m_inImageB[i][k];
		}
	}
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			old = m_inImageB[i][k];
			new1 = (int)((double)(old - low) / (double)(high - low) * 255.0);

			if (new1 > 255)
				new1 = 255;
			if (new1 < 0)
				new1 = 0;
			m_outImageB[i][k] = new1;
		}
	}
}


void CColorImageProcessingDoc::OnEddin()
{
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	
	//**진짜 영상처리 알고리즘**
	//R
	int high = m_inImageR[0][0], low = m_inImageR[0][0];
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			if (m_inImageR[i][k] < low)
				low = m_inImageR[i][k];
			if (m_inImageR[i][k] > high)
				high = m_inImageR[i][k];
		}
	}
	high -= 50;
	low += 50;
	int old, new1;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			old = m_inImageR[i][k];
			new1 = (int)((double)(old - low) / (double)(high - low) * 255.0);

			if (new1 > 255)
				new1 = 255;
			if (new1 < 0)
				new1 = 0;
			m_outImageR[i][k] = new1;
		}
	}
	//G
	high = m_inImageG[0][0], low = m_inImageG[0][0];
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			if (m_inImageG[i][k] < low)
				low = m_inImageG[i][k];
			if (m_inImageG[i][k] > high)
				high = m_inImageG[i][k];
		}
	}
	high -= 50;
	low += 50;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			old = m_inImageG[i][k];
			new1 = (int)((double)(old - low) / (double)(high - low) * 255.0);

			if (new1 > 255)
				new1 = 255;
			if (new1 < 0)
				new1 = 0;
			m_outImageG[i][k] = new1;
		}
	}
	//B
	high = m_inImageB[0][0], low = m_inImageB[0][0];
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			if (m_inImageB[i][k] < low)
				low = m_inImageB[i][k];
			if (m_inImageB[i][k] > high)
				high = m_inImageB[i][k];
		}
	}
	high -= 50;
	low += 50;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			old = m_inImageB[i][k];
			new1 = (int)((double)(old - low) / (double)(high - low) * 255.0);

			if (new1 > 255)
				new1 = 255;
			if (new1 < 0)
				new1 = 0;
			m_outImageB[i][k] = new1;
		}
	}
}


void CColorImageProcessingDoc::OnHistoequalImage()
{
	//기존 메모리 해제
	OnFreeOutImage();
	// TODO: 여기에 구현 코드 추가.

	//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	//메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
	m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
	//1단계 : 빈도수 세기(=히스토그램) histo[256]
	int histoR[256] = { 0, }, histoG[256] = { 0, }, histoB[256] = { 0, };
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			histoR[m_inImageR[i][k]]++;
			histoG[m_inImageR[i][k]]++;
			histoB[m_inImageR[i][k]]++;
		}
	}
	//2단계 : 누적 히스토그램 생성
	int sumHistoR[256] = { 0, }, sumHistoG[256] = { 0, }, sumHistoB[256] = { 0, };
	sumHistoR[0] = histoR[0];
	sumHistoG[0] = histoG[0];
	sumHistoB[0] = histoB[0];
	for (int i = 1; i < 256; i++) {
		sumHistoR[i] = sumHistoR[i - 1] + histoR[i];
		sumHistoG[i] = sumHistoG[i - 1] + histoG[i];
		sumHistoB[i] = sumHistoB[i - 1] + histoB[i];
	}

	//3단계 : 정규화된 히스토그램 생성 normalHisto = sumHisto *(1.0/inH*inW)*255.0;
	double normalHistoR[256] = { 1.0, }, normalHistoG[256] = { 1.0, }, normalHistoB[256] = { 1.0, };
	for (int i = 0; i < 256; i++) {
		normalHistoR[i] = sumHistoR[i] * (1.0 / (m_inH * m_inW)) * 255.0;
		normalHistoG[i] = sumHistoG[i] * (1.0 / (m_inH * m_inW)) * 255.0;
		normalHistoB[i] = sumHistoB[i] * (1.0 / (m_inH * m_inW)) * 255.0;
	}

	//4단계 : inImage를 정규화된 이미지로 치환

	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			m_outImageR[i][k] = (unsigned char)normalHistoR[m_inImageR[i][k]];
			m_outImageG[i][k] = (unsigned char)normalHistoG[m_inImageG[i][k]];
			m_outImageB[i][k] = (unsigned char)normalHistoB[m_inImageB[i][k]];
		}
	}

}


void CColorImageProcessingDoc::OnEmbossHsi()
{
	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW,0);
	m_outImageG = OnMalloc2D(m_outH, m_outW,0);
	m_outImageB = OnMalloc2D(m_outH, m_outW,0);
	// ** 진짜 영상처리 알고리즘 **
	const int MSIZE = 3;
	double mask[MSIZE][MSIZE] = {  // 엠보싱 마스크
		{ -1.0, 0.0, 0.0 },
		{  0.0, 0.0, 0.0 },
		{  0.0, 0.0, 1.0 } };

	// 임시 메모리 할당
	double** tmpInImageR, ** tmpInImageG, ** tmpInImageB, ** tmpOutImageR, ** tmpOutImageG, ** tmpOutImageB;
	double** tmpInImageH, ** tmpInImageS, ** tmpInImageI;
	tmpInImageR = OnMalloc2DDouble(m_inH + 2, m_inW + 2,127);
	tmpInImageG = OnMalloc2DDouble(m_inH + 2, m_inW + 2,127);
	tmpInImageB = OnMalloc2DDouble(m_inH + 2, m_inW + 2,127);

	tmpInImageH = OnMalloc2DDouble(m_inH + 2, m_inW + 2,0);
	tmpInImageS = OnMalloc2DDouble(m_inH + 2, m_inW + 2,0);
	tmpInImageI = OnMalloc2DDouble(m_inH + 2, m_inW + 2,0);

	tmpOutImageR = OnMalloc2DDouble(m_outH, m_outW,0);
	tmpOutImageG = OnMalloc2DDouble(m_outH, m_outW,0);
	tmpOutImageB = OnMalloc2DDouble(m_outH, m_outW,0);


	// 입력메모리 --> 임시입력메모리
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	///////// RGB 모델 --> HSI 모델 ///////////////
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double* hsi;
			unsigned char R, G, B;
			R = tmpInImageR[i][k]; G = tmpInImageG[i][k]; B = tmpInImageB[i][k];
			hsi = RGB2HSI(R, G, B);

			double H, S, I;
			H = hsi[0]; S = hsi[1]; I = hsi[2];
			tmpInImageH[i][k] = H; tmpInImageS[i][k] = S; tmpInImageI[i][k] = I;
		}
	}
	// *** 회선 연산 : 마스크로 긁어가면서 계산하기.	
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double S_VALUE = 0.0;
			for (int m = 0; m < MSIZE; m++)
				for (int n = 0; n < MSIZE; n++)
					S_VALUE += tmpInImageI[i + m][k + n] * mask[m][n];
			tmpInImageI[i][k] = S_VALUE;
		}
	}

	// 후처리 (마스크의 합계에 따라서 127을 더할지 결정)
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageI[i][k] += 127;
		}

	////// HSI --> RGB ////////
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			unsigned char* rgb;
			double H, S, I;

			H = tmpInImageH[i][k]; S = tmpInImageS[i][k]; I = tmpInImageI[i][k];

			rgb = HSI2RGB(H, S, I);
			tmpOutImageR[i][k] = rgb[0]; tmpOutImageG[i][k] = rgb[1]; tmpOutImageB[i][k] = rgb[2];
		}


	// 임시 출력 이미지 ---> 출력 이미지
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];

			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];

			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];

		}


	// 임시 메모리 해제
	OnFree2DDouble(tmpInImageR, m_inH + 2);
	OnFree2DDouble(tmpInImageG, m_inH + 2);
	OnFree2DDouble(tmpInImageB, m_inH + 2);
	OnFree2DDouble(tmpInImageH, m_inH + 2);
	OnFree2DDouble(tmpInImageS, m_inH + 2);
	OnFree2DDouble(tmpInImageI, m_inH + 2);
	OnFree2DDouble(tmpOutImageR, m_outH);
	OnFree2DDouble(tmpOutImageG, m_outH);
	OnFree2DDouble(tmpOutImageB, m_outH);
}







void CColorImageProcessingDoc::OnMopping()
{
	// TODO: 여기에 구현 코드 추가.
	CConstantDlg dlg;
	if (moppingcount == 1) {//모핑중
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				m_outImageR[i][k] = ((m_maxmopping - m_mopping) / m_maxmopping) * m_inImageR[i][k] + ((m_mopping) / m_maxmopping) * m_maskCalR[i][k];
				m_outImageG[i][k] = ((m_maxmopping - m_mopping) / m_maxmopping) * m_inImageG[i][k] + ((m_mopping) / m_maxmopping) * m_maskCalG[i][k];
				m_outImageB[i][k] = ((m_maxmopping - m_mopping) / m_maxmopping) * m_inImageB[i][k] + ((m_mopping) / m_maxmopping) * m_maskCalB[i][k];
			}
		}
	}
	else if (moppingcount == 0) {//모핑 처음
		if (dlg.DoModal() == IDOK) {
			// TODO: 여기에 구현 코드 추가.
	//기존 메모리 해제
			OnFreeOutImage();
			// TODO: 여기에 구현 코드 추가.
			m_mopping = 0;
			//중요! 출력이미지 크기 결정 --> 알고리즘에 따름...
			m_outH = m_inH;
			m_outW = m_inW;
			//메모리 할당
			m_outImageR = OnMalloc2D(m_outH, m_outW, 0);
			m_outImageG = OnMalloc2D(m_outH, m_outW, 0);
			m_outImageB = OnMalloc2D(m_outH, m_outW, 0);
			OnMalloc2DMaskCal(); // 2번째 이미지 할당
			m_maxmopping = (double)dlg.m_constant;
			if (m_maskCalH != m_inH && m_maskCalW != m_inW) {//모핑 파일 크기가 안맞을때 모핑 처음으로 초기화
				moppingcount = 0;
				AfxMessageBox(_T("같은 크기만 가능 합니다."));
				OnFreeMaskCalImage();
				return;
			}

			
			//**진짜 영상처리 알고리즘**
			for (int i = 0; i < m_outH; i++) {
				for (int k = 0; k < m_outW; k++) {
					m_outImageR[i][k] = ((m_maxmopping - m_mopping) / m_maxmopping) * m_inImageR[i][k] + ((m_mopping) / m_maxmopping) * m_maskCalR[i][k];
					m_outImageG[i][k] = ((m_maxmopping - m_mopping) / m_maxmopping) * m_inImageG[i][k] + ((m_mopping) / m_maxmopping) * m_maskCalG[i][k];
					m_outImageB[i][k] = ((m_maxmopping - m_mopping) / m_maxmopping) * m_inImageB[i][k] + ((m_mopping) / m_maxmopping) * m_maskCalB[i][k];
				}
			}
			moppingcount = 1;//모핑 시작
		}
	}
			
	
}


