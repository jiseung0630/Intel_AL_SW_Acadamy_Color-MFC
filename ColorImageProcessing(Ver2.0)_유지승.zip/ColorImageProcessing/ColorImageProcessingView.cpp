﻿
// ColorImageProcessingView.cpp: CColorImageProcessingView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "ColorImageProcessing.h"
#endif

#include "ColorImageProcessingDoc.h"
#include "ColorImageProcessingView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CColorImageProcessingView

IMPLEMENT_DYNCREATE(CColorImageProcessingView, CView)

BEGIN_MESSAGE_MAP(CColorImageProcessingView, CView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_COMMAND(IDM_EQUAL_IMAGE, &CColorImageProcessingView::OnEqualImage)
	ON_COMMAND(ID_GRAY_SCALE, &CColorImageProcessingView::OnGrayScale)
	ON_COMMAND(IDM_ADD_IMAGE, &CColorImageProcessingView::OnAddImage)
	ON_COMMAND(IDM_OP_IMAGE, &CColorImageProcessingView::OnOpImage)
	ON_COMMAND(IDM_BLACK_IMAGE, &CColorImageProcessingView::OnBlackImage)
	ON_COMMAND(IDM_CHANGE_SATUR, &CColorImageProcessingView::OnChangeSatur)
	ON_COMMAND(IDM_PICK_COLOR, &CColorImageProcessingView::OnPickColor)
	ON_COMMAND(ID_OR_IMAGE, &CColorImageProcessingView::OnOrImage)
	ON_COMMAND(IDM_AND_IMAGE, &CColorImageProcessingView::OnAndImage)
	ON_COMMAND(IDM_XOR_IMAGE, &CColorImageProcessingView::OnXorImage)
	ON_COMMAND(IDM_INVALUE_IMAGE, &CColorImageProcessingView::OnInvalueImage)
	ON_COMMAND(IDm_ZOOMOUT, &CColorImageProcessingView::OnZoomout)
	ON_COMMAND(IDM_ZOOMIN, &CColorImageProcessingView::OnZoomin)
	ON_COMMAND(IDM_MOVE, &CColorImageProcessingView::OnMove)
	ON_COMMAND(IDM_ROTATE, &CColorImageProcessingView::OnRotate)
	ON_COMMAND(IDM_ZOOM_ROTATE, &CColorImageProcessingView::OnZoomRotate)
	ON_COMMAND(IDM_UDMIRROE, &CColorImageProcessingView::OnUdmirroe)
	ON_COMMAND(IDM_LRMIRROE, &CColorImageProcessingView::OnLrmirroe)
	ON_COMMAND(IDM_EMBOSS, &CColorImageProcessingView::OnEmboss)
	ON_COMMAND(IDM_BLUR, &CColorImageProcessingView::OnBlur)
	ON_COMMAND(IDM_SHARPNING, &CColorImageProcessingView::OnSharpning)
	ON_COMMAND(IDM_HIGH_SHARPNING, &CColorImageProcessingView::OnHighSharpning)
	ON_COMMAND(ID_HOR_EDGE, &CColorImageProcessingView::OnHorEdge)
	ON_COMMAND(IDM_VER_EDGE, &CColorImageProcessingView::OnVerEdge)
	ON_COMMAND(IDM_SIM_CAL, &CColorImageProcessingView::OnSimCal)
	ON_COMMAND(IDM_DIV_CAL, &CColorImageProcessingView::OnDivCal)
	ON_COMMAND(IDM_STREATCH, &CColorImageProcessingView::OnStreatch)
	ON_COMMAND(IDM_EDDIN, &CColorImageProcessingView::OnEddin)
	ON_COMMAND(IDM_HISTOEQUAL_IMAGE, &CColorImageProcessingView::OnHistoequalImage)
	ON_COMMAND(IDM_EMBOSS_HSI, &CColorImageProcessingView::OnEmbossHsi)
	ON_COMMAND(IDM_SHARPNING_HSI, &CColorImageProcessingView::OnSharpningHsi)
	ON_COMMAND(IDM_HIGH_SHARPNING_HSI, &CColorImageProcessingView::OnHighSharpningHsi)
	ON_COMMAND(IDM_HOREDGE_HSI, &CColorImageProcessingView::OnHoredgeHsi)
	ON_COMMAND(IDM_VEREDGE_HSI, &CColorImageProcessingView::OnVeredgeHsi)
	ON_COMMAND(IDM_SIMCAL_HSI, &CColorImageProcessingView::OnSimcalHsi)
	ON_COMMAND(IDM_DIVCAL_HSI, &CColorImageProcessingView::OnDivcalHsi)
	ON_COMMAND(IDM_MOPPING, &CColorImageProcessingView::OnMopping)
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CColorImageProcessingView 생성/소멸

CColorImageProcessingView::CColorImageProcessingView() noexcept
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CColorImageProcessingView::~CColorImageProcessingView()
{
}

BOOL CColorImageProcessingView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CColorImageProcessingView 그리기

void CColorImageProcessingView::OnDraw(CDC* pDC)
{
	//CColorImageAlpha1Doc* pDoc = GetDocument();
	//ASSERT_VALID(pDoc);
	//if (!pDoc)
	//	return;

	//// TODO: 여기에 원시 데이터에 대한 그리기 코드를 추가합니다.
	//int R, G, B;
	//for (int i=0; i<pDoc->m_inH; i++)
	//	for (int k = 0; k < pDoc->m_inW; k++) {
	//		R = pDoc->m_inImageR[i][k];
	//		G = pDoc->m_inImageG[i][k];
	//		B = pDoc->m_inImageB[i][k];
	//		pDC->SetPixel(k + 5, i + 5, RGB(R, G, B));
	//	}

	//for (int i = 0; i < pDoc->m_outH; i++)
	//	for (int k = 0; k < pDoc->m_outW; k++) {
	//		R = pDoc->m_outImageR[i][k];
	//		G = pDoc->m_outImageG[i][k];
	//		B = pDoc->m_outImageB[i][k];
	//		pDC->SetPixel(pDoc->m_inW + k + 5 + 5, i + 5, RGB(R, G, B));
	//	}

	/////////////////////
	///// ** 더블 버퍼링 **
	/////////////////////
	//CColorImageProcessingDoc* pDoc = GetDocument();
	//ASSERT_VALID(pDoc);
	//if (!pDoc)
	//	return;

	///////////////////////
	///// 성능 개선을 위한 더블 버퍼링 
	//////////////////////
	//int i, k;
	//unsigned char R, G, B;
	//// 메모리 DC 선언
	//CDC memDC;
	//CBitmap* pOldBitmap, bitmap;

	//// 화면 DC와 호환되는 메모리 DC 객체를 생성
	//memDC.CreateCompatibleDC(pDC);

	//// 마찬가지로 화면 DC와 호환되는 Bitmap 생성
	//bitmap.CreateCompatibleBitmap(pDC, pDoc->m_inW, pDoc->m_inH);

	//pOldBitmap = memDC.SelectObject(&bitmap);
	//memDC.PatBlt(0, 0, pDoc->m_inW, pDoc->m_inH, WHITENESS); // 흰색으로 초기화

	//// 메모리 DC에 그리기
	//for (i = 0; i < pDoc->m_inH; i++) {
	//	for (k = 0; k < pDoc->m_inW; k++) {
	//		R = pDoc->m_inImageR[i][k];
	//		G = pDoc->m_inImageG[i][k];
	//		B = pDoc->m_inImageB[i][k];
	//		memDC.SetPixel(k, i, RGB(R, G, B));
	//	}
	//}
	//// 메모리 DC를 화면 DC에 고속 복사
	//pDC->BitBlt(5, 5, pDoc->m_inW, pDoc->m_inH, &memDC, 0, 0, SRCCOPY);

	//memDC.SelectObject(pOldBitmap);
	//memDC.DeleteDC();
	//bitmap.DeleteObject();

	/////////////////////

	//// 화면 DC와 호환되는 메모리 DC 객체를 생성
	//memDC.CreateCompatibleDC(pDC);

	//// 마찬가지로 화면 DC와 호환되는 Bitmap 생성
	//bitmap.CreateCompatibleBitmap(pDC, pDoc->m_outW, pDoc->m_outH);

	//pOldBitmap = memDC.SelectObject(&bitmap);
	//memDC.PatBlt(0, 0, pDoc->m_outW, pDoc->m_outH, WHITENESS); // 흰색으로 초기화

	//// 메모리 DC에 그리기
	//for (i = 0; i < pDoc->m_outH; i++) {
	//	for (k = 0; k < pDoc->m_outW; k++) {
	//		R = pDoc->m_outImageR[i][k];
	//		G = pDoc->m_outImageG[i][k];
	//		B = pDoc->m_outImageB[i][k];
	//		memDC.SetPixel(k, i, RGB(R, G, B));
	//	}
	//}
	//// 메모리 DC를 화면 DC에 고속 복사
	//pDC->BitBlt(pDoc->m_inW + 10, 5, pDoc->m_outW, pDoc->m_outH, &memDC, 0, 0, SRCCOPY);

	//memDC.SelectObject(pOldBitmap);
	//memDC.DeleteDC();
	//bitmap.DeleteObject();

	///////////////////
	/// ** 더블 버퍼링 **
	///////////////////
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	/////////////////////
	/// 화면크기 조절
	////////////////////
	int i, k;
	unsigned char R, G, B;
	// 메모리 DC 선언
	CDC memDC;
	CBitmap* pOldBitmap, bitmap;

	// 화면 DC와 호환되는 메모리 DC 객체를 생성
	memDC.CreateCompatibleDC(pDC);

	// 마찬가지로 화면 DC와 호환되는 Bitmap 생성
	bitmap.CreateCompatibleBitmap(pDC, pDoc->m_inW, pDoc->m_inH);

	pOldBitmap = memDC.SelectObject(&bitmap);
	memDC.PatBlt(0, 0, pDoc->m_inW, pDoc->m_inH, WHITENESS); // 흰색으로 초기화

	//출력 영상의 크기를 자동 조절
	double MAXSIZE = 800; // 필요시 실 모니터 또는 화면의 해상도에 따라서 변경 가능
	int inH = pDoc->m_inH;
	int inW = pDoc->m_inW;
	double hop = 1.0;//기본

	if (inH > MAXSIZE || inW > MAXSIZE) {
		//hop을 새로 계산.
		if (inW > inH)
			hop = (inW / MAXSIZE);
		else
			hop = (inH / MAXSIZE);
		inW = (int)(inW / hop);
		inH = (int)(inH / hop);
	}
	
	// 메모리 DC에 그리기


	for (i = 0; i < inH; i++) {
		for (k = 0; k < inW; k++) {
			R = pDoc->m_inImageR[(int)(i*hop)][(int)(k*hop)];
			G = pDoc->m_inImageG[(int)(i * hop)][(int)(k * hop)];
			B = pDoc->m_inImageB[(int)(i * hop)][(int)(k * hop)];
			memDC.SetPixel(k, i, RGB(R, G, B));
		}
	}
	// 메모리 DC를 화면 DC에 고속 복사
	pDC->BitBlt(5, 5, pDoc->m_inW, pDoc->m_inH, &memDC, 0, 0, SRCCOPY);

	memDC.SelectObject(pOldBitmap);
	memDC.DeleteDC();
	bitmap.DeleteObject();

	///////////////////

	// 화면 DC와 호환되는 메모리 DC 객체를 생성
	memDC.CreateCompatibleDC(pDC);

	// 마찬가지로 화면 DC와 호환되는 Bitmap 생성
	bitmap.CreateCompatibleBitmap(pDC, pDoc->m_outW, pDoc->m_outH);

	pOldBitmap = memDC.SelectObject(&bitmap);
	memDC.PatBlt(0, 0, pDoc->m_outW, pDoc->m_outH, WHITENESS); // 흰색으로 초기화

	int outH = pDoc->m_outH;
	int outW = pDoc->m_outW;
	hop = 1.0;//기본

	if (outH > MAXSIZE || outW > MAXSIZE) {
		//hop을 새로 계산.
		if (outW > outH)
			hop = (outW / MAXSIZE);
		else
			hop = (outH / MAXSIZE);
		outW = (int)(outW / hop);
		outH = (int)(outH / hop);
	}
	// 메모리 DC에 그리기
	for (i = 0; i < outH; i++) {
		for (k = 0; k < outW; k++) {
			R = pDoc->m_outImageR[(int)(i * hop)][(int)(k * hop)];
			G = pDoc->m_outImageG[(int)(i * hop)][(int)(k * hop)];
			B = pDoc->m_outImageB[(int)(i * hop)][(int)(k * hop)];
			memDC.SetPixel(k, i, RGB(R, G, B));
		}
	}
	// 메모리 DC를 화면 DC에 고속 복사
	pDC->BitBlt(inW + 10, 5, pDoc->m_outW, pDoc->m_outH, &memDC, 0, 0, SRCCOPY);

	memDC.SelectObject(pOldBitmap);
	memDC.DeleteDC();
	bitmap.DeleteObject();}


// CColorImageProcessingView 인쇄

BOOL CColorImageProcessingView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CColorImageProcessingView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CColorImageProcessingView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}


// CColorImageProcessingView 진단

#ifdef _DEBUG
void CColorImageProcessingView::AssertValid() const
{
	CView::AssertValid();
}

void CColorImageProcessingView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CColorImageProcessingDoc* CColorImageProcessingView::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CColorImageProcessingDoc)));
	return (CColorImageProcessingDoc*)m_pDocument;
}
#endif //_DEBUG


// CColorImageProcessingView 메시지 처리기


void CColorImageProcessingView::OnEqualImage()
{
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnEqualImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnGrayScale()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnGrayScale();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnAddImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnAddImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnOpImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnOpImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnBlackImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnBlackImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnChangeSatur()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnChangeSatur();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnPickColor()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnPickColor();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnOrImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnOrImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnAndImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnAndImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnXorImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnXorImage();
	Invalidate(TRUE);

}


void CColorImageProcessingView::OnInvalueImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnInvalueImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnZoomout()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnZoomout();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnZoomin()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	pDoc->OnZoomin();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnMove()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnMove();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnRotate()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnRotate();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnZoomRotate()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnZoomRotate();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnUdmirroe()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnUdmirroe();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnLrmirroe()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	

	pDoc->OnLrmirroe();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnEmboss()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnEmboss();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnBlur()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnBlur();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnSharpning()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnSharpning();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnHighSharpning()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnHighSharpning();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnHorEdge()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnHorEdge();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnVerEdge()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnVerEdge();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnSimCal()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnSimCal();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnDivCal()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnDivCal();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnStreatch()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnStreatch();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnEddin()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnEddin();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnHistoequalImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnHistoequalImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnEmbossHsi()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnEmbossHsi();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnSharpningHsi()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnSharpningHsi();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnHighSharpningHsi()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnHighSharpningHsi();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnHoredgeHsi()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnHoredgeHsi();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnVeredgeHsi()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnVeredgeHsi();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnSimcalHsi()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnSimcalHsi();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnDivcalHsi()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	pDoc->OnDivcalHsi();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnMopping()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnMopping();
	if (pDoc->moppingcount == 1)
	{
		Invalidate(TRUE);
	}
}


void CColorImageProcessingView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
	if (pDoc->m_mopping < pDoc->m_maxmopping) {
		switch (nChar) {
		case VK_UP:
			pDoc->moppingcount = 1;
			pDoc->m_mopping++;
			break;
		case VK_DOWN:
			pDoc->moppingcount = 1;
			pDoc->m_mopping++;
			break;
		case VK_LEFT:
			pDoc->moppingcount = 1;
			pDoc->m_mopping++;
			break;
		case VK_RIGHT:
			pDoc->moppingcount = 1;
			pDoc->m_mopping++;
			break;
		}
		pDoc->OnMopping();
		Invalidate(TRUE);
	}
	else if (pDoc->m_mopping == pDoc->m_maxmopping) {
		AfxMessageBox(_T("모핑 종료"));
		pDoc->moppingcount = 0;
		pDoc->OnFreeMaskCalImage();
	}
}
