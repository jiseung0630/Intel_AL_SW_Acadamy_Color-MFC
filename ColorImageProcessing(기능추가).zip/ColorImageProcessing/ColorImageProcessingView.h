﻿
// ColorImageProcessingView.h: CColorImageProcessingView 클래스의 인터페이스
//

#pragma once


class CColorImageProcessingView : public CView
{
protected: // serialization에서만 만들어집니다.
	CColorImageProcessingView() noexcept;
	DECLARE_DYNCREATE(CColorImageProcessingView)

// 특성입니다.
public:
	CColorImageProcessingDoc* GetDocument() const;

// 작업입니다.
public:

// 재정의입니다.
public:
	virtual void OnDraw(CDC* pDC);  // 이 뷰를 그리기 위해 재정의되었습니다.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 구현입니다.
public:
	virtual ~CColorImageProcessingView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 생성된 메시지 맵 함수
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEqualImage();
	afx_msg void OnGrayScale();
	afx_msg void OnAddImage();
	afx_msg void OnOpImage();
	afx_msg void OnBlackImage();
	afx_msg void OnChangeSatur();
	afx_msg void OnPickColor();
	afx_msg void OnOrImage();
	afx_msg void OnAndImage();
	afx_msg void OnXorImage();
	afx_msg void OnInvalueImage();
	afx_msg void OnZoomout();
	afx_msg void OnZoomin();
	afx_msg void OnMove();
	afx_msg void OnRotate();
	afx_msg void OnZoomRotate();
	afx_msg void OnUdmirroe();
	afx_msg void OnLrmirroe();
	afx_msg void OnEmboss();
	afx_msg void OnBlur();
	afx_msg void OnSharpning();
	afx_msg void OnHighSharpning();
	afx_msg void OnHorEdge();
	afx_msg void OnVerEdge();
	afx_msg void OnSimCal();
	afx_msg void OnDivCal();
	afx_msg void OnStreatch();
	afx_msg void OnEddin();
	afx_msg void OnHistoequalImage();
	afx_msg void OnEmbossHsi();
	afx_msg void OnSharpningHsi();
	afx_msg void OnHighSharpningHsi();
	afx_msg void OnHoredgeHsi();
	afx_msg void OnVeredgeHsi();
	afx_msg void OnSimcalHsi();
	afx_msg void OnDivcalHsi();
	afx_msg void OnMopping();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
};

#ifndef _DEBUG  // ColorImageProcessingView.cpp의 디버그 버전
inline CColorImageProcessingDoc* CColorImageProcessingView::GetDocument() const
   { return reinterpret_cast<CColorImageProcessingDoc*>(m_pDocument); }
#endif

