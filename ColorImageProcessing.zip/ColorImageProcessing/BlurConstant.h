﻿#pragma once
#include "afxdialogex.h"


// CBlurConstant 대화 상자

class CBlurConstant : public CDialogEx
{
	DECLARE_DYNAMIC(CBlurConstant)

public:
	CBlurConstant(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CBlurConstant();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_BLUR_CONSTANT };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	// 홀수값만 가능
	int m_blurconstant;
};
