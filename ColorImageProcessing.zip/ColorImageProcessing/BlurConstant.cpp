﻿// BlurConstant.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageProcessing.h"
#include "afxdialogex.h"
#include "BlurConstant.h"


// CBlurConstant 대화 상자

IMPLEMENT_DYNAMIC(CBlurConstant, CDialog)

CBlurConstant::CBlurConstant(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_BLUR_CONSTANT, pParent)
	, m_blurconstant(0)
{

}

CBlurConstant::~CBlurConstant()
{
}

void CBlurConstant::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_BLUR_CONSTANT, m_blurconstant);
	DDV_MinMaxInt(pDX, m_blurconstant, 0, INT_MAX);
}


BEGIN_MESSAGE_MAP(CBlurConstant, CDialog)
END_MESSAGE_MAP()


// CBlurConstant 메시지 처리기
