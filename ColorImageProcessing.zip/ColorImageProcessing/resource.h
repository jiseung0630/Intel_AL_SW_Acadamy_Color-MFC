﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// ColorImageProcessing.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ColorImageProcessingTYPE    130
#define IDD_CONSTANT                    310
#define IDD_XYCONSTANT                  312
#define IDD_BLUR                        314
#define IDD_BLUR_CONSTANT               314
#define IDC_EDIT_CONSTANT               1000
#define IDC_EDIT1                       1001
#define IDC_EDIT2                       1002
#define IDC_EDIT_BLUR_CONSTANT          1003
#define ID_32771                        32771
#define ID_32772                        32772
#define IDM_EQUAL_IMAGE                 32773
#define ID_GRAY_SCALE                   32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_32781                        32781
#define ID_32782                        32782
#define ID_32783                        32783
#define ID_32784                        32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_32787                        32787
#define ID_32788                        32788
#define ID_32789                        32789
#define ID_32790                        32790
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_32794                        32794
#define ID_32795                        32795
#define ID_32796                        32796
#define ID_32797                        32797
#define ID_32798                        32798
#define ID_32799                        32799
#define ID_32800                        32800
#define ID_32801                        32801
#define ID_32802                        32802
#define IDM_ADD_IMAGE                   32803
#define IDM_OP_IMAGE                    32804
#define IDM_BLACK_IMAGE                 32805
#define ID_OR_IMAGE                     32806
#define IDM_AND_IMAGE                   32807
#define IDM_XOR_IMAGE                   32808
#define IDM_                            32809
#define IDM_INVALUE_IMAGE               32810
#define ID_32811                        32811
#define IDM_CHANGE_SATUR                32812
#define ID_32813                        32813
#define IDM_PICK_COLOR                  32814
#define IDm_ZOOMOUT                     32815
#define IDM_ZOOMIN                      32816
#define IDM_MOVE                        32817
#define IDM_ROTATE                      32818
#define IDM_ZOOM_ROTATE                 32819
#define IDM_UDMIRROE                    32820
#define IDM_LRMIRROE                    32821
#define IDM_EMBOSS                      32822
#define IDM_BLUR                        32823
#define IDM_SHARPNING                   32824
#define IDM_HIGH_SHARPNING              32825
#define ID_HOR_EDGE                     32826
#define IDM_VER_EDGE                    32827
#define IDM_SIMCAL                      32828
#define IDM_DIV_CAL                     32829
#define IDM_SIM_CAL                     32830

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        316
#define _APS_NEXT_COMMAND_VALUE         32831
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
