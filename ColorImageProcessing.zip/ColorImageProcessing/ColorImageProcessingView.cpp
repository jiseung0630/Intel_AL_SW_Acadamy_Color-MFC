﻿
// ColorImageProcessingView.cpp: CColorImageProcessingView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "ColorImageProcessing.h"
#endif

#include "ColorImageProcessingDoc.h"
#include "ColorImageProcessingView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CColorImageProcessingView

IMPLEMENT_DYNCREATE(CColorImageProcessingView, CView)

BEGIN_MESSAGE_MAP(CColorImageProcessingView, CView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_COMMAND(IDM_EQUAL_IMAGE, &CColorImageProcessingView::OnEqualImage)
	ON_COMMAND(ID_GRAY_SCALE, &CColorImageProcessingView::OnGrayScale)
	ON_COMMAND(IDM_ADD_IMAGE, &CColorImageProcessingView::OnAddImage)
	ON_COMMAND(IDM_OP_IMAGE, &CColorImageProcessingView::OnOpImage)
	ON_COMMAND(IDM_BLACK_IMAGE, &CColorImageProcessingView::OnBlackImage)
	ON_COMMAND(IDM_CHANGE_SATUR, &CColorImageProcessingView::OnChangeSatur)
	ON_COMMAND(IDM_PICK_COLOR, &CColorImageProcessingView::OnPickColor)
	ON_COMMAND(ID_OR_IMAGE, &CColorImageProcessingView::OnOrImage)
	ON_COMMAND(IDM_AND_IMAGE, &CColorImageProcessingView::OnAndImage)
	ON_COMMAND(IDM_XOR_IMAGE, &CColorImageProcessingView::OnXorImage)
	ON_COMMAND(IDM_INVALUE_IMAGE, &CColorImageProcessingView::OnInvalueImage)
	ON_COMMAND(IDm_ZOOMOUT, &CColorImageProcessingView::OnZoomout)
	ON_COMMAND(IDM_ZOOMIN, &CColorImageProcessingView::OnZoomin)
	ON_COMMAND(IDM_MOVE, &CColorImageProcessingView::OnMove)
	ON_COMMAND(IDM_ROTATE, &CColorImageProcessingView::OnRotate)
	ON_COMMAND(IDM_ZOOM_ROTATE, &CColorImageProcessingView::OnZoomRotate)
	ON_COMMAND(IDM_UDMIRROE, &CColorImageProcessingView::OnUdmirroe)
	ON_COMMAND(IDM_LRMIRROE, &CColorImageProcessingView::OnLrmirroe)
	ON_COMMAND(IDM_EMBOSS, &CColorImageProcessingView::OnEmboss)
	ON_COMMAND(IDM_BLUR, &CColorImageProcessingView::OnBlur)
END_MESSAGE_MAP()

// CColorImageProcessingView 생성/소멸

CColorImageProcessingView::CColorImageProcessingView() noexcept
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CColorImageProcessingView::~CColorImageProcessingView()
{
}

BOOL CColorImageProcessingView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CColorImageProcessingView 그리기

void CColorImageProcessingView::OnDraw(CDC* pDC)
{
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 여기에 원시 데이터에 대한 그리기 코드를 추가합니다.
	int R, G, B;
	for (int i = 0; i < pDoc->m_inH; i++)
		for (int k = 0; k < pDoc->m_inW; k++) {
			R = pDoc->m_inImageR[i][k];
			G = pDoc->m_inImageG[i][k];
			B = pDoc->m_inImageB[i][k];
			pDC->SetPixel(k + 5, i + 5, RGB(R, G, B));
		}

	for (int i = 0; i < pDoc->m_outH; i++)
		for (int k = 0; k < pDoc->m_outW; k++) {
			R = pDoc->m_outImageR[i][k];
			G = pDoc->m_outImageG[i][k];
			B = pDoc->m_outImageB[i][k];
			pDC->SetPixel(pDoc->m_inW + k + 5 + 5, i + 5, RGB(R, G, B));
		}
}


// CColorImageProcessingView 인쇄

BOOL CColorImageProcessingView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CColorImageProcessingView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CColorImageProcessingView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}


// CColorImageProcessingView 진단

#ifdef _DEBUG
void CColorImageProcessingView::AssertValid() const
{
	CView::AssertValid();
}

void CColorImageProcessingView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CColorImageProcessingDoc* CColorImageProcessingView::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CColorImageProcessingDoc)));
	return (CColorImageProcessingDoc*)m_pDocument;
}
#endif //_DEBUG


// CColorImageProcessingView 메시지 처리기


void CColorImageProcessingView::OnEqualImage()
{
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnEqualImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnGrayScale()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnGrayScale();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnAddImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnAddImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnOpImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnOpImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnBlackImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnBlackImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnChangeSatur()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnChangeSatur();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnPickColor()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnPickColor();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnOrImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnOrImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnAndImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnAndImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnXorImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnXorImage();
	Invalidate(TRUE);

}


void CColorImageProcessingView::OnInvalueImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnInvalueImage();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnZoomout()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnZoomout();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnZoomin()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnZoomin();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnMove()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnMove();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnRotate()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnRotate();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnZoomRotate()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnZoomRotate();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnUdmirroe()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnUdmirroe();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnLrmirroe()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnLrmirroe();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnEmboss()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnEmboss();
	Invalidate(TRUE);
}


void CColorImageProcessingView::OnBlur()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageProcessingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: 여기에 명령 처리기 코드를 추가합니다.

	pDoc->OnBlur();
	Invalidate(TRUE);
}
